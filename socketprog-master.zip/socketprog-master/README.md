# socketprog
Implementing various features of socket programming

## Network Applications - 1

Client sends an english sentence in lowercase to
the server. Server has to convert all the lowercase
to uppercase and revert back to the client. Here
server is to provide a service of converting
lowercase to uppercase sentences.

USE TCP

## Network Application - 2

Client sends an integer to the server and server has to
provide its square and cube.

USE TCP

## Network Application - 3

create a chat facility from point to point communication.(Bonus: you can create a one server multiple client architecture)

USE TCP

## Network Application - 4

Cheak whether a given string is palandrome or not?

USE IP

## Network Application - 5

cheak wheather a number is even or not?

USE IP

## Contributers 
Asutosh Ghanto,Bhargava,Anirudha,Dheeraj
